package com.infy.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dto.CustomerDTO;
import com.infy.dto.MobileDTO;
import com.infy.entity.Customer;
import com.infy.repository.CustomerRepository;


@Service(value="customerService")
@Transactional

public class CustomerServiceImpl implements CustomerService {
    @Autowired
	private CustomerRepository CustomerRepository;
	@Override
	public CustomerDTO getCustomer(Integer customerId) throws Exception {

		Optional<Customer> optional = CustomerRepository.findById(customerId);
		Customer customer = optional.orElseThrow(() -> new Exception("Service.INVALID_CUSTOMERID"));
		CustomerDTO customerDTO = new CustomerDTO();
		customerDTO.setCustomerId(customer.getCustomerId());
		customerDTO.setCustomerName(customer.getCustomerName());
		customerDTO.setAddress(customer.getAddress());
	
		MobileDTO mobileDTO = new MobileDTO();
		mobileDTO.setMobileId(customer.getMobile().getMobileId());
		mobileDTO.setCompanyName(customer.getMobile().getCompanyName());
		mobileDTO.setModelName(customer.getMobile().getModelName());
		mobileDTO.setRam(customer.getMobile().getRam());
		mobileDTO.setOs(customer.getMobile().getOs());
		mobileDTO.setPrice(customer.getMobile().getPrice());
		
		
		customerDTO.setMobile(mobileDTO);
		return customerDTO;
	}

	@Override
	public List<CustomerDTO> getCustomerDetails() throws Exception {

		Iterable<Customer> customers = CustomerRepository.findAll();
		List<CustomerDTO> customers2 = new ArrayList<>();
		customers.forEach(customer -> {
			CustomerDTO cust = new CustomerDTO();
			cust.setCustomerId(customer.getCustomerId());
			cust.setCustomerName(customer.getCustomerName());
			cust.setAddress(customer.getAddress());
			customers2.add(cust);
		});
		if (customers2.isEmpty())
			throw new Exception("Service.CUSTOMERS_NOT_FOUND");
		return customers2;
	}

	

}
