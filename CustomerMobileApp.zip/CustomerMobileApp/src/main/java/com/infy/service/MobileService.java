package com.infy.service;

import java.util.List;

import com.infy.dto.MobileDTO;

public interface MobileService {

	public List<MobileDTO> getMobileDetails() throws Exception;

}
