package com.infy.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dto.MobileDTO;
import com.infy.entity.Mobile;
import com.infy.repository.MobileRepository;


@Service(value="mobileService")
@Transactional
public class MobileServiceImpl implements MobileService {

	@Autowired
	private MobileRepository MobileRepository;
	
	@Override
	public List<MobileDTO> getMobileDetails() throws Exception {
		Iterable<Mobile> mobiles = MobileRepository.findAll();
		List<MobileDTO> mobiles2 = new ArrayList<>();
		mobiles.forEach(mobile -> {
			MobileDTO cust = new MobileDTO();
			cust.setMobileId(mobile.getMobileId());
			cust.setCompanyName(mobile.getCompanyName());
			cust.setModelName(mobile.getModelName());
			cust.setRam(mobile.getRam());
			cust.setOs(mobile.getOs());
			cust.setPrice(mobile.getPrice());
			mobiles2.add(cust);
		});
		if (mobiles2.isEmpty())
			throw new Exception("Service.CUSTOMERS_NOT_FOUND");
		return mobiles2;
	
	}
	

}
