package com.infy.repository;

import org.springframework.data.repository.CrudRepository;

import com.infy.entity.Mobile;

public interface MobileRepository extends CrudRepository<Mobile,Integer>{

	
}
